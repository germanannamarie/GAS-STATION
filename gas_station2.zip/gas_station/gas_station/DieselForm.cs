﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gas_station
{
    public partial class DieselForm : Form
    {
        public DieselForm()
        {
            InitializeComponent();
        }

        private void siticoneButton12_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu main = new Menu();
            main.Show();
        }
    }
}
