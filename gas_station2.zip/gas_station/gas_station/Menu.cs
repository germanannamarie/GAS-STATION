﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gas_station
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void siticoneHtmlLabel2_Click(object sender, EventArgs e)
        {

        }

        private void siticonePictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            PremiumForm PF = new PremiumForm();
            PF.Show();
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            UnleadedForm UF = new UnleadedForm();
            UF.Show();
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            DieselForm DF = new DieselForm();
            DF.Show();
        }

        private void siticonePictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
