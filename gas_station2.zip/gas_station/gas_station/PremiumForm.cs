﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gas_station
{
    public partial class PremiumForm : Form
    {
        public PremiumForm()
        {
            InitializeComponent();
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            AmountText.Text = "3";
        }

        private void siticoneButton8_Click(object sender, EventArgs e)
        {
            AmountText.Text = "8";
        }

        private void siticoneButton10_Click(object sender, EventArgs e)
        {
            AmountText.Text = "0";
        }

        private void siticoneButton12_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu main = new Menu();
            main.Show();
        }

        private void siticoneButton9_Click(object sender, EventArgs e)
        {
            AmountText.Text = "9";
        }

        private void siticoneButton11_Click(object sender, EventArgs e)
        {
            AmountText.Clear();
        }

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            AmountText.Text = "4";
        }

        private void siticoneButton6_Click(object sender, EventArgs e)
        {
            AmountText.Text = "6";
        }

        private void one_Click(object sender, EventArgs e)
        {
            AmountText.Text = "1";
            
            
        }

        private void AmountText_MouseClick(object sender, MouseEventArgs e)
        {
             
        }

        private void siticoneButton13_Click(object sender, EventArgs e)
        {

        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {

        }

        private void siticoneButton3_Click_1(object sender, EventArgs e)
        {

        }

        private void siticoneButton4_Click_1(object sender, EventArgs e)
        {

        }

        private void siticoneButton5_Click(object sender, EventArgs e)
        {

        }

        private void siticoneButton6_Click_1(object sender, EventArgs e)
        {

        }

        private void siticoneButton7_Click(object sender, EventArgs e)
        {

        }

        private void siticoneButton8_Click_1(object sender, EventArgs e)
        {

        }

        private void siticoneButton9_Click_1(object sender, EventArgs e)
        {

        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {

        }

        private void siticoneButton11_Click_1(object sender, EventArgs e)
        {

        }

        private void siticoneButton12_Click_1(object sender, EventArgs e)
        {

        }

        private void siticoneButton10_Click_1(object sender, EventArgs e)
        {

        }

        private void siticoneButton14_Click(object sender, EventArgs e)
        {

        }

        private void two_Click(object sender, EventArgs e)
        {
            AmountText.Text = "2";
        }

        private void five_Click(object sender, EventArgs e)
        {
            AmountText.Text = "5";
        }

        private void seven_Click(object sender, EventArgs e)
        {
            AmountText.Text = "7";
        }
    }
}
