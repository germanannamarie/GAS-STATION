﻿namespace gas_station
{
    partial class SwipeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.siticoneHScrollBar1 = new Siticone.Desktop.UI.WinForms.SiticoneHScrollBar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.siticoneTextBox1 = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.siticoneTextBox2 = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.siticoneButton1 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton12 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton11 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton10 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton9 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton8 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton7 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton6 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton5 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton4 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton3 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton2 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton14 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneTextBox3 = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // siticoneHScrollBar1
            // 
            this.siticoneHScrollBar1.InUpdate = false;
            this.siticoneHScrollBar1.LargeChange = 10;
            this.siticoneHScrollBar1.Location = new System.Drawing.Point(114, 123);
            this.siticoneHScrollBar1.Name = "siticoneHScrollBar1";
            this.siticoneHScrollBar1.ScrollbarSize = 26;
            this.siticoneHScrollBar1.Size = new System.Drawing.Size(419, 26);
            this.siticoneHScrollBar1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightGray;
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.siticoneTextBox3);
            this.groupBox1.Controls.Add(this.siticoneButton1);
            this.groupBox1.Controls.Add(this.siticoneButton12);
            this.groupBox1.Controls.Add(this.siticoneButton11);
            this.groupBox1.Controls.Add(this.siticoneButton10);
            this.groupBox1.Controls.Add(this.siticoneButton9);
            this.groupBox1.Controls.Add(this.siticoneButton8);
            this.groupBox1.Controls.Add(this.siticoneButton7);
            this.groupBox1.Controls.Add(this.siticoneButton6);
            this.groupBox1.Controls.Add(this.siticoneButton5);
            this.groupBox1.Controls.Add(this.siticoneButton4);
            this.groupBox1.Controls.Add(this.siticoneButton3);
            this.groupBox1.Controls.Add(this.siticoneButton2);
            this.groupBox1.Controls.Add(this.siticoneButton14);
            this.groupBox1.Location = new System.Drawing.Point(114, 155);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(419, 315);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(184, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 25);
            this.label1.TabIndex = 31;
            this.label1.Text = "P R I C E :";
            // 
            // siticoneTextBox1
            // 
            this.siticoneTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.siticoneTextBox1.DefaultText = "";
            this.siticoneTextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.siticoneTextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.siticoneTextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneTextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox1.Location = new System.Drawing.Point(295, 17);
            this.siticoneTextBox1.Name = "siticoneTextBox1";
            this.siticoneTextBox1.PasswordChar = '\0';
            this.siticoneTextBox1.PlaceholderText = "";
            this.siticoneTextBox1.SelectedText = "";
            this.siticoneTextBox1.Size = new System.Drawing.Size(200, 25);
            this.siticoneTextBox1.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(90, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 22);
            this.label2.TabIndex = 33;
            this.label2.Text = "You\'re about to buy:";
            // 
            // siticoneTextBox2
            // 
            this.siticoneTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.siticoneTextBox2.DefaultText = "";
            this.siticoneTextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.siticoneTextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.siticoneTextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneTextBox2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox2.Location = new System.Drawing.Point(295, 66);
            this.siticoneTextBox2.Name = "siticoneTextBox2";
            this.siticoneTextBox2.PasswordChar = '\0';
            this.siticoneTextBox2.PlaceholderText = "";
            this.siticoneTextBox2.SelectedText = "";
            this.siticoneTextBox2.Size = new System.Drawing.Size(200, 25);
            this.siticoneTextBox2.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(248, 16);
            this.label3.TabIndex = 35;
            this.label3.Text = "Swipe your Credit Card here ---->>>>>";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // siticoneButton1
            // 
            this.siticoneButton1.BorderRadius = 15;
            this.siticoneButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton1.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton1.ForeColor = System.Drawing.Color.White;
            this.siticoneButton1.Location = new System.Drawing.Point(290, 222);
            this.siticoneButton1.Name = "siticoneButton1";
            this.siticoneButton1.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton1.TabIndex = 41;
            this.siticoneButton1.Text = "ENTER";
            // 
            // siticoneButton12
            // 
            this.siticoneButton12.BorderRadius = 15;
            this.siticoneButton12.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton12.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton12.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton12.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton12.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton12.ForeColor = System.Drawing.Color.White;
            this.siticoneButton12.Location = new System.Drawing.Point(166, 264);
            this.siticoneButton12.Name = "siticoneButton12";
            this.siticoneButton12.Size = new System.Drawing.Size(85, 34);
            this.siticoneButton12.TabIndex = 40;
            this.siticoneButton12.Text = "EXIT";
            // 
            // siticoneButton11
            // 
            this.siticoneButton11.BorderRadius = 15;
            this.siticoneButton11.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton11.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton11.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton11.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton11.ForeColor = System.Drawing.Color.White;
            this.siticoneButton11.Location = new System.Drawing.Point(40, 222);
            this.siticoneButton11.Name = "siticoneButton11";
            this.siticoneButton11.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton11.TabIndex = 39;
            this.siticoneButton11.Text = "CLEAR";
            // 
            // siticoneButton10
            // 
            this.siticoneButton10.BorderRadius = 15;
            this.siticoneButton10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton10.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton10.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton10.ForeColor = System.Drawing.Color.White;
            this.siticoneButton10.Location = new System.Drawing.Point(166, 222);
            this.siticoneButton10.Name = "siticoneButton10";
            this.siticoneButton10.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton10.TabIndex = 38;
            this.siticoneButton10.Text = "0";
            // 
            // siticoneButton9
            // 
            this.siticoneButton9.BorderRadius = 15;
            this.siticoneButton9.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton9.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton9.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton9.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton9.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton9.ForeColor = System.Drawing.Color.White;
            this.siticoneButton9.Location = new System.Drawing.Point(290, 180);
            this.siticoneButton9.Name = "siticoneButton9";
            this.siticoneButton9.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton9.TabIndex = 37;
            this.siticoneButton9.Text = "9";
            // 
            // siticoneButton8
            // 
            this.siticoneButton8.BorderRadius = 15;
            this.siticoneButton8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton8.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton8.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton8.ForeColor = System.Drawing.Color.White;
            this.siticoneButton8.Location = new System.Drawing.Point(166, 180);
            this.siticoneButton8.Name = "siticoneButton8";
            this.siticoneButton8.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton8.TabIndex = 36;
            this.siticoneButton8.Text = "8";
            // 
            // siticoneButton7
            // 
            this.siticoneButton7.BorderRadius = 15;
            this.siticoneButton7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton7.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton7.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton7.ForeColor = System.Drawing.Color.White;
            this.siticoneButton7.Location = new System.Drawing.Point(40, 180);
            this.siticoneButton7.Name = "siticoneButton7";
            this.siticoneButton7.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton7.TabIndex = 35;
            this.siticoneButton7.Text = "7";
            // 
            // siticoneButton6
            // 
            this.siticoneButton6.BorderRadius = 15;
            this.siticoneButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton6.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton6.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton6.ForeColor = System.Drawing.Color.White;
            this.siticoneButton6.Location = new System.Drawing.Point(290, 138);
            this.siticoneButton6.Name = "siticoneButton6";
            this.siticoneButton6.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton6.TabIndex = 34;
            this.siticoneButton6.Text = "6";
            // 
            // siticoneButton5
            // 
            this.siticoneButton5.BorderRadius = 15;
            this.siticoneButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton5.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton5.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton5.ForeColor = System.Drawing.Color.White;
            this.siticoneButton5.Location = new System.Drawing.Point(166, 138);
            this.siticoneButton5.Name = "siticoneButton5";
            this.siticoneButton5.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton5.TabIndex = 33;
            this.siticoneButton5.Text = "5";
            // 
            // siticoneButton4
            // 
            this.siticoneButton4.BorderRadius = 15;
            this.siticoneButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton4.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton4.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton4.ForeColor = System.Drawing.Color.White;
            this.siticoneButton4.Location = new System.Drawing.Point(40, 138);
            this.siticoneButton4.Name = "siticoneButton4";
            this.siticoneButton4.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton4.TabIndex = 32;
            this.siticoneButton4.Text = "4";
            // 
            // siticoneButton3
            // 
            this.siticoneButton3.BorderRadius = 15;
            this.siticoneButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton3.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton3.ForeColor = System.Drawing.Color.White;
            this.siticoneButton3.Location = new System.Drawing.Point(290, 96);
            this.siticoneButton3.Name = "siticoneButton3";
            this.siticoneButton3.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton3.TabIndex = 31;
            this.siticoneButton3.Text = "3";
            // 
            // siticoneButton2
            // 
            this.siticoneButton2.BorderRadius = 15;
            this.siticoneButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton2.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton2.ForeColor = System.Drawing.Color.White;
            this.siticoneButton2.Location = new System.Drawing.Point(166, 96);
            this.siticoneButton2.Name = "siticoneButton2";
            this.siticoneButton2.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton2.TabIndex = 30;
            this.siticoneButton2.Text = "2";
            // 
            // siticoneButton14
            // 
            this.siticoneButton14.BorderRadius = 15;
            this.siticoneButton14.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton14.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton14.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton14.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton14.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton14.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton14.ForeColor = System.Drawing.Color.White;
            this.siticoneButton14.Location = new System.Drawing.Point(40, 96);
            this.siticoneButton14.Name = "siticoneButton14";
            this.siticoneButton14.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton14.TabIndex = 29;
            this.siticoneButton14.Text = "1";
            // 
            // siticoneTextBox3
            // 
            this.siticoneTextBox3.BackColor = System.Drawing.Color.Silver;
            this.siticoneTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.siticoneTextBox3.DefaultText = "";
            this.siticoneTextBox3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.siticoneTextBox3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.siticoneTextBox3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.siticoneTextBox3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneTextBox3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox3.Location = new System.Drawing.Point(119, 41);
            this.siticoneTextBox3.Name = "siticoneTextBox3";
            this.siticoneTextBox3.PasswordChar = '\0';
            this.siticoneTextBox3.PlaceholderText = "";
            this.siticoneTextBox3.SelectedText = "";
            this.siticoneTextBox3.Size = new System.Drawing.Size(182, 36);
            this.siticoneTextBox3.TabIndex = 42;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(115, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 22);
            this.label4.TabIndex = 36;
            this.label4.Text = "Enter your Card PIN";
            // 
            // SwipeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(155)))), ((int)(((byte)(157)))));
            this.ClientSize = new System.Drawing.Size(611, 502);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.siticoneTextBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.siticoneTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.siticoneHScrollBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SwipeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SwipeForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Siticone.Desktop.UI.WinForms.SiticoneHScrollBar siticoneHScrollBar1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox siticoneTextBox1;
        private System.Windows.Forms.Label label2;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox siticoneTextBox2;
        private System.Windows.Forms.Label label3;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton1;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton12;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton11;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton10;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton9;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton8;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton7;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton6;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton5;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton4;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton3;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton2;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton14;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox siticoneTextBox3;
        private System.Windows.Forms.Label label4;
    }
}