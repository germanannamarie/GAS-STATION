﻿namespace gas_station
{
    partial class UnleadedForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UnleadedForm));
            this.siticoneHtmlLabel2 = new Siticone.Desktop.UI.WinForms.SiticoneHtmlLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.siticonePanel1 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.Enter = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.Exit = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.Clear = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton10 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.nine = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.eight = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.seven = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.six = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.five = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.four = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.three = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.two = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.one = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneTextBox2 = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.siticoneTextBox1 = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.siticoneButton14 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.SuspendLayout();
            // 
            // siticoneHtmlLabel2
            // 
            this.siticoneHtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.siticoneHtmlLabel2.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneHtmlLabel2.ForeColor = System.Drawing.Color.White;
            this.siticoneHtmlLabel2.Location = new System.Drawing.Point(166, 40);
            this.siticoneHtmlLabel2.Name = "siticoneHtmlLabel2";
            this.siticoneHtmlLabel2.Size = new System.Drawing.Size(356, 34);
            this.siticoneHtmlLabel2.TabIndex = 10;
            this.siticoneHtmlLabel2.Text = "G A S O L I N E S T A T I O N";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(244, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 32);
            this.label1.TabIndex = 9;
            this.label1.Text = "K U M & G O ";
            this.label1.UseMnemonic = false;
            // 
            // siticonePanel1
            // 
            this.siticonePanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("siticonePanel1.BackgroundImage")));
            this.siticonePanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.siticonePanel1.Location = new System.Drawing.Point(12, 85);
            this.siticonePanel1.Name = "siticonePanel1";
            this.siticonePanel1.Size = new System.Drawing.Size(269, 355);
            this.siticonePanel1.TabIndex = 11;
            // 
            // Enter
            // 
            this.Enter.BorderRadius = 15;
            this.Enter.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Enter.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Enter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Enter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Enter.FillColor = System.Drawing.Color.Gray;
            this.Enter.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enter.ForeColor = System.Drawing.Color.White;
            this.Enter.Location = new System.Drawing.Point(580, 323);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(85, 36);
            this.Enter.TabIndex = 44;
            this.Enter.Text = "ENTER";
            this.Enter.Click += new System.EventHandler(this.Enter_Click);
            // 
            // Exit
            // 
            this.Exit.BorderRadius = 15;
            this.Exit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Exit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Exit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Exit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Exit.FillColor = System.Drawing.Color.Gray;
            this.Exit.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.Location = new System.Drawing.Point(456, 366);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(85, 34);
            this.Exit.TabIndex = 43;
            this.Exit.Text = "EXIT";
            this.Exit.Click += new System.EventHandler(this.siticoneButton12_Click);
            // 
            // Clear
            // 
            this.Clear.BorderRadius = 15;
            this.Clear.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Clear.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Clear.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Clear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Clear.FillColor = System.Drawing.Color.Gray;
            this.Clear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.ForeColor = System.Drawing.Color.White;
            this.Clear.Location = new System.Drawing.Point(330, 323);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(85, 36);
            this.Clear.TabIndex = 42;
            this.Clear.Text = "CLEAR";
            // 
            // siticoneButton10
            // 
            this.siticoneButton10.BorderRadius = 15;
            this.siticoneButton10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton10.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton10.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton10.ForeColor = System.Drawing.Color.White;
            this.siticoneButton10.Location = new System.Drawing.Point(456, 323);
            this.siticoneButton10.Name = "siticoneButton10";
            this.siticoneButton10.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton10.TabIndex = 41;
            this.siticoneButton10.Text = "0";
            // 
            // nine
            // 
            this.nine.BorderRadius = 15;
            this.nine.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.nine.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.nine.FillColor = System.Drawing.Color.Gray;
            this.nine.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nine.ForeColor = System.Drawing.Color.White;
            this.nine.Location = new System.Drawing.Point(580, 281);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(85, 36);
            this.nine.TabIndex = 40;
            this.nine.Text = "9";
            // 
            // eight
            // 
            this.eight.BorderRadius = 15;
            this.eight.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.eight.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.eight.FillColor = System.Drawing.Color.Gray;
            this.eight.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight.ForeColor = System.Drawing.Color.White;
            this.eight.Location = new System.Drawing.Point(456, 281);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(85, 36);
            this.eight.TabIndex = 39;
            this.eight.Text = "8";
            // 
            // seven
            // 
            this.seven.BorderRadius = 15;
            this.seven.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.seven.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.seven.FillColor = System.Drawing.Color.Gray;
            this.seven.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven.ForeColor = System.Drawing.Color.White;
            this.seven.Location = new System.Drawing.Point(330, 281);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(85, 36);
            this.seven.TabIndex = 38;
            this.seven.Text = "7";
            // 
            // six
            // 
            this.six.BorderRadius = 15;
            this.six.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.six.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.six.FillColor = System.Drawing.Color.Gray;
            this.six.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six.ForeColor = System.Drawing.Color.White;
            this.six.Location = new System.Drawing.Point(580, 239);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(85, 36);
            this.six.TabIndex = 37;
            this.six.Text = "6";
            // 
            // five
            // 
            this.five.BorderRadius = 15;
            this.five.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.five.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.five.FillColor = System.Drawing.Color.Gray;
            this.five.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five.ForeColor = System.Drawing.Color.White;
            this.five.Location = new System.Drawing.Point(456, 239);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(85, 36);
            this.five.TabIndex = 36;
            this.five.Text = "5";
            // 
            // four
            // 
            this.four.BorderRadius = 15;
            this.four.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.four.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.four.FillColor = System.Drawing.Color.Gray;
            this.four.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four.ForeColor = System.Drawing.Color.White;
            this.four.Location = new System.Drawing.Point(330, 239);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(85, 36);
            this.four.TabIndex = 35;
            this.four.Text = "4";
            // 
            // three
            // 
            this.three.BorderRadius = 15;
            this.three.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.three.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.three.FillColor = System.Drawing.Color.Gray;
            this.three.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three.ForeColor = System.Drawing.Color.White;
            this.three.Location = new System.Drawing.Point(580, 197);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(85, 36);
            this.three.TabIndex = 34;
            this.three.Text = "3";
            // 
            // two
            // 
            this.two.BorderRadius = 15;
            this.two.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.two.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.two.FillColor = System.Drawing.Color.Gray;
            this.two.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two.ForeColor = System.Drawing.Color.White;
            this.two.Location = new System.Drawing.Point(456, 197);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(85, 36);
            this.two.TabIndex = 33;
            this.two.Text = "2";
            // 
            // one
            // 
            this.one.BorderRadius = 15;
            this.one.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.one.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.one.FillColor = System.Drawing.Color.Gray;
            this.one.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one.ForeColor = System.Drawing.Color.White;
            this.one.Location = new System.Drawing.Point(330, 197);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(85, 36);
            this.one.TabIndex = 32;
            this.one.Text = "1";
            this.one.Click += new System.EventHandler(this.siticoneButton1_Click);
            // 
            // siticoneTextBox2
            // 
            this.siticoneTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.siticoneTextBox2.DefaultText = "";
            this.siticoneTextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.siticoneTextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.siticoneTextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneTextBox2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox2.Location = new System.Drawing.Point(388, 116);
            this.siticoneTextBox2.Name = "siticoneTextBox2";
            this.siticoneTextBox2.PasswordChar = '\0';
            this.siticoneTextBox2.PlaceholderText = "";
            this.siticoneTextBox2.SelectedText = "";
            this.siticoneTextBox2.Size = new System.Drawing.Size(277, 25);
            this.siticoneTextBox2.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(287, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 25);
            this.label3.TabIndex = 30;
            this.label3.Text = "A M O U N T :";
            // 
            // siticoneTextBox1
            // 
            this.siticoneTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.siticoneTextBox1.DefaultText = "";
            this.siticoneTextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.siticoneTextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.siticoneTextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneTextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneTextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneTextBox1.Location = new System.Drawing.Point(439, 85);
            this.siticoneTextBox1.Name = "siticoneTextBox1";
            this.siticoneTextBox1.PasswordChar = '\0';
            this.siticoneTextBox1.PlaceholderText = "";
            this.siticoneTextBox1.SelectedText = "";
            this.siticoneTextBox1.Size = new System.Drawing.Size(226, 25);
            this.siticoneTextBox1.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(287, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 25);
            this.label4.TabIndex = 45;
            this.label4.Text = "L I T E R :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(65, 450);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 25);
            this.label2.TabIndex = 46;
            this.label2.Text = "U N L E A D E D";
            // 
            // siticoneButton14
            // 
            this.siticoneButton14.BorderRadius = 15;
            this.siticoneButton14.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton14.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton14.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton14.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton14.FillColor = System.Drawing.Color.Gray;
            this.siticoneButton14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton14.ForeColor = System.Drawing.Color.White;
            this.siticoneButton14.Location = new System.Drawing.Point(671, 85);
            this.siticoneButton14.Name = "siticoneButton14";
            this.siticoneButton14.Size = new System.Drawing.Size(115, 46);
            this.siticoneButton14.TabIndex = 47;
            this.siticoneButton14.Text = "COMPUTE";
            // 
            // UnleadedForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(181)))), ((int)(((byte)(198)))));
            this.ClientSize = new System.Drawing.Size(794, 494);
            this.Controls.Add(this.siticoneButton14);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Enter);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.siticoneButton10);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.six);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.three);
            this.Controls.Add(this.two);
            this.Controls.Add(this.one);
            this.Controls.Add(this.siticoneTextBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.siticoneTextBox1);
            this.Controls.Add(this.siticonePanel1);
            this.Controls.Add(this.siticoneHtmlLabel2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UnleadedForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UnleadedForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Siticone.Desktop.UI.WinForms.SiticoneHtmlLabel siticoneHtmlLabel2;
        private System.Windows.Forms.Label label1;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel1;
        private Siticone.Desktop.UI.WinForms.SiticoneButton Enter;
        private Siticone.Desktop.UI.WinForms.SiticoneButton Exit;
        private Siticone.Desktop.UI.WinForms.SiticoneButton Clear;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton10;
        private Siticone.Desktop.UI.WinForms.SiticoneButton nine;
        private Siticone.Desktop.UI.WinForms.SiticoneButton eight;
        private Siticone.Desktop.UI.WinForms.SiticoneButton seven;
        private Siticone.Desktop.UI.WinForms.SiticoneButton six;
        private Siticone.Desktop.UI.WinForms.SiticoneButton five;
        private Siticone.Desktop.UI.WinForms.SiticoneButton four;
        private Siticone.Desktop.UI.WinForms.SiticoneButton three;
        private Siticone.Desktop.UI.WinForms.SiticoneButton two;
        private Siticone.Desktop.UI.WinForms.SiticoneButton one;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox siticoneTextBox2;
        private System.Windows.Forms.Label label3;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox siticoneTextBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton14;
    }
}