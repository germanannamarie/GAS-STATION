﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gas_station
{
    public partial class UnleadedForm : Form
    {
        public UnleadedForm()
        {
            InitializeComponent();
        }

        private void siticoneButton12_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            Menu main = new Menu();
            main.Show();
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void Enter_Click(object sender, EventArgs e)
        {

        }
    }
}
